package ejercicios;

public class MensajeSecreto {
    public static void main(String[] args) {
        // definir mensaje original
        String mensaje = "   Hola_mundo secreto__   ";
        // mostrar mensaje en consola
        System.out.println(mensaje);

        // Calcular y guardar el mensaje original
        int longitudOriginal = mensaje.length();
        System.out.println("Longitud del mensaje original: " + longitudOriginal);

        // Eliminar espacios
        String trimmed = mensaje.trim(); // trim() quita los espacios anteriores

        // mostrar mensaje despues de trimp
        System.out.println("Mensaje despues del trim: " + trimmed);

        // remplaza los guiones bajos por espacios
        String reemplazo = trimmed.replace("_", " ");
        System.out.println("Mensaje despues del remplazo: " + reemplazo);

        // colapsar dobles espacios (si aparecen) y hacer trim final
        reemplazo = reemplazo.replace("  ", " "); // convierte "  " → " "
        String procesado = reemplazo.trim();       // quitar posibles espacios al inicio o final

// Mostrar mensaje procesado final
        System.out.println("Mensaje procesado: " + procesado);
        System.out.println("Longitud del mensaje procesado: " + procesado.length());

    }
}
